package com.example.xpenso
//import android.content.Context
//import android.content.Intent
//import android.graphics.Color
//import android.provider.SyncStateContract
//import android.support.v7.widget.RecyclerView
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import android.widget.TextView
//import com.example.xpenso.transactionDb.AppDatabase
//import com.example.xpenso.transactionDb.TransactionEntry
//import java.text.SimpleDateFormat
//
//
//class CustomAdapter(var context: Context, transactionEntries: List<TransactionEntry>?) :
//    RecyclerView.Adapter<CustomAdapter.ViewHolder>() {
//    private val transactionEntries: List<TransactionEntry>?
//    private var appDatabase: AppDatabase? = null
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
//        val view = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false)
//        return ViewHolder(view)
//    }
//
//    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        val amount: String
//        holder.categoryTextViewrv.setText(transactionEntries!![position].getCategory())
//        if (transactionEntries!![position].getTransactionType()
//                .equals(SyncStateContract.Constants.incomeCategory)
//        ) {
//            amount = "+" + transactionEntries[position].getAmount()
//            holder.amountTextViewrv.text = amount
//            holder.amountTextViewrv.setTextColor(Color.parseColor("#aeea00"))
//        } else {
//            amount = "-" + transactionEntries[position].getAmount()
//            holder.amountTextViewrv.text = amount
//            holder.amountTextViewrv.setTextColor(Color.parseColor("#ff5722"))
//        }
//        val sdf = SimpleDateFormat("dd-MM-yyyy")
//        val dateToBeSet = sdf.format(transactionEntries[position].getDate())
//        holder.dateTextViewrv.text = dateToBeSet
//        holder.descriptionTextViewrv.setText(transactionEntries[position].getDescription())
//    }
//
//    override fun getItemCount(): Int {
//        return if (transactionEntries == null || transactionEntries.size == 0) {
//            0
//        } else {
//            transactionEntries.size
//        }
//    }
//
//    fun getTransactionEntries(): List<TransactionEntry>? {
//        return transactionEntries
//    }
//
//    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
//        var categoryTextViewrv: TextView
//        var amountTextViewrv: TextView
//        var descriptionTextViewrv: TextView
//        var dateTextViewrv: TextView
//
//        init {
//            categoryTextViewrv = itemView.findViewById(R.id.categoryTextViewrv)
//            amountTextViewrv = itemView.findViewById(R.id.amountTextViewrv)
//            descriptionTextViewrv = itemView.findViewById(R.id.descriptionTextViewrv)
//            dateTextViewrv = itemView.findViewById(R.id.dateTextViewrv)
//            appDatabase = AppDatabase.getInstance(context)
//            itemView.setOnClickListener {
//                val intent = Intent(context, AddExpenseActivity::class.java)
//                val sdf = SimpleDateFormat("dd-MM-yyyy")
//                val date = sdf.format(transactionEntries!![adapterPosition].getDate())
//                if (transactionEntries[adapterPosition].getTransactionType()
//                        .equals(SyncStateContract.Constants.incomeCategory)
//                ) {
//                    intent.putExtra("from", SyncStateContract.Constants.editIncomeString)
//                    intent.putExtra("amount", transactionEntries[adapterPosition].getAmount())
//                    intent.putExtra(
//                        "description",
//                        transactionEntries[adapterPosition].getDescription()
//                    )
//                    intent.putExtra("date", date)
//                    intent.putExtra("id", transactionEntries[adapterPosition].getId())
//                } else {
//                    intent.putExtra("from", SyncStateContract.Constants.editExpenseString)
//                    intent.putExtra("amount", transactionEntries[adapterPosition].getAmount())
//                    intent.putExtra(
//                        "description",
//                        transactionEntries[adapterPosition].getDescription()
//                    )
//                    intent.putExtra("date", date)
//                    intent.putExtra("category", transactionEntries[adapterPosition].getCategory())
//                    intent.putExtra("id", transactionEntries[adapterPosition].getId())
//                }
//
//
//               context.startActivity(intent)
//            }
//        }
//    }
//
//    init {
//        this.transactionEntries = transactionEntries
//    }
//}