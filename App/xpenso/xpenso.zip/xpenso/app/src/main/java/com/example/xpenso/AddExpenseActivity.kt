package com.example.xpenso

import android.app.DatePickerDialog
import android.app.DatePickerDialog.OnDateSetListener
import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.os.Handler
import android.provider.SyncStateContract
import android.support.design.widget.Snackbar
import android.support.design.widget.TextInputEditText
import android.support.design.widget.TextInputLayout
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
//import com.example.xpenso.AppDatabase
//import com.example.xpenso.AppExecutors
//import com.example.xpenso.TransactionEntry
//import com.example.xpenso.TransactionViewModel
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

abstract class AddExpenseActivity : AppCompatActivity() {
    var amountTextInputEditText: TextInputEditText? = null
    var descriptionTextInputEditText: TextInputEditText? = null
    var amountTextInputLayout: TextInputLayout? = null
    var descriptionTextInputLayout: TextInputLayout? = null
    var dateTextView: TextView? = null
    var dateLinearLayout: LinearLayout? = null
    var categorySpinner: Spinner? = null
    var categories: ArrayList<String?>? = null
    var myCalendar: Calendar? = null
    var description: String? = null
    var dateOfExpense: Date? = null
    private val datePickerDialog: DatePickerDialog?=null


    //These variables contain data which will be stored permanently on hitting save button
    var amount = 0
    var categoryOfExpense : String? = null                    //This parameter is to decide category in a transaction

    var categoryOfTransaction : String? = null                           //This parameter to decide whether it is income and expense


    //Variable to keep track from where it came to this activity
    var intentFrom: String? = null
    // var transactionViewModel: TransactionViewModel? = null
    var transactionid = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_expense)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        //appDatabase = AppDatabase.getInstance(applicationContext)
        //transactionViewModel = ViewModelProviders.of(this).get(TransactionViewModel::class.java)
        categories = ArrayList()
        myCalendar = Calendar.getInstance()
//setDateToTextView()

//        //First task here is to determine from where this activity is launched from the 4 possibilities
//        val intent = intent
//        intentFrom = intent.getStringExtra("from")
//        if (intentFrom == SyncStateContract.Constants.addIncomeString) {
//            categoryOfTransaction = SyncStateContract.Constants.incomeCategory
//            title = "Add Income"
//            categories!!.add("Income")
//            categorySpinner.setClickable(false)
//            categorySpinner.setEnabled(false)
//            categorySpinner.setAdapter(
//                ArrayAdapter(
//                    this@AddExpenseActivity, android.R.layout.simple_list_item_1,
//                    categories!!
//                )
//            )
//        } else if (intentFrom == SyncStateContract.Constants.addExpenseString) {
//            categoryOfTransaction = SyncStateContract.Constants.expenseCategory
//            title = "Add Expense"
//            categories!!.add("Food")
//            categories!!.add("Travel")
//            categories!!.add("Clothes")
//            categories!!.add("Movies")
//            categories!!.add("Health")
//            categories!!.add("Grocery")
//            categories!!.add("Other")
//            categorySpinner.setAdapter(
//                ArrayAdapter(
//                    this@AddExpenseActivity,
//                    android.R.layout.simple_list_item_1, categories!!
//                )
//            )
//        } else if (intentFrom == SyncStateContract.Constants.editIncomeString) {
//            title = "Edit Income"
//            amountTextInputEditText.setText(intent.getIntExtra("amount", 0).toString())
//            amountTextInputEditText.setSelection(amountTextInputEditText.getText()!!.length)
//            descriptionTextInputEditText.setText(intent.getStringExtra("description"))
//            descriptionTextInputEditText.setSelection(descriptionTextInputEditText.getText()!!.length)
//            transactionid = intent.getIntExtra("id", -1)
//            val sdf = SimpleDateFormat("dd-MM-yyyy")
//            try {
//                val date = sdf.parse(intent.getStringExtra("date"))
//                myCalendar.setTime(date)
//            } catch (e: ParseException) {
//                e.printStackTrace()
//            }
//            dateTextView.setText(intent.getStringExtra("date"))
//            categoryOfTransaction = SyncStateContract.Constants.incomeCategory
//            categories!!.add("Income")
//            categorySpinner.setClickable(false)
//            categorySpinner.setEnabled(false)
//            categorySpinner.setAdapter(
//                ArrayAdapter(
//                    this@AddExpenseActivity, android.R.layout.simple_list_item_1,
//                    categories!!
//                )
//            )
//        } else if (intentFrom == SyncStateContract.Constants.editExpenseString) {
//            categoryOfTransaction = SyncStateContract.Constants.expenseCategory
//            title = "Edit Expense"
//            amountTextInputEditText.setText(intent.getIntExtra("amount", 0).toString())
//            amountTextInputEditText.setSelection(amountTextInputEditText.getText()!!.length)
//            descriptionTextInputEditText.setText(intent.getStringExtra("description"))
//            descriptionTextInputEditText.setSelection(descriptionTextInputEditText.getText()!!.length)
//            dateTextView.setText(intent.getStringExtra("date"))
//            transactionid = intent.getIntExtra("id", -1)
//            val sdf = SimpleDateFormat("dd-MM-yyyy")
//            try {
//                val date = sdf.parse(intent.getStringExtra("date"))
//                myCalendar.setTime(date)
//            } catch (e: ParseException) {
//                e.printStackTrace()
//            }
//            categories!!.add("Food")
//            categories!!.add("Travel")
//            categories!!.add("Clothes")
//            categories!!.add("Movies")
//            categories!!.add("Health")
//            categories!!.add("Grocery")
//            categories!!.add("Other")
//            categorySpinner.setAdapter(
//                ArrayAdapter(
//                    this@AddExpenseActivity, android.R.layout.simple_list_item_1,
//                    categories!!
//                )
//            )
//            categorySpinner.setSelection(categories!!.indexOf(intent.getStringExtra("category")))
//        }
//        dateLinearLayout.setOnClickListener(View.OnClickListener { showDatePicker() })
//    }
//
//    fun showDatePicker() {
//        val dateSetListener =
//            OnDateSetListener { view, year, month, dayOfMonth ->
//                myCalendar!![Calendar.YEAR] = year
//                myCalendar!![Calendar.MONTH] = month
//                myCalendar!![Calendar.DAY_OF_MONTH] = dayOfMonth
//                setDateToTextView()
//            }
//        val datePickerDialog = DatePickerDialog(
//            this@AddExpenseActivity, dateSetListener,
//            myCalendar!![Calendar.YEAR],
//            myCalendar!![Calendar.MONTH], myCalendar!![Calendar.DAY_OF_MONTH]
//        )
//        datePickerDialog.datePicker.maxDate = System.currentTimeMillis()
//        datePickerDialog.show()
//
//    }
//
//    fun setDateToTextView() {
//        val date = myCalendar!!.time
//        val sdf = SimpleDateFormat("dd-MM-yyyy")
//        val dateToBeSet = sdf.format(date)
//        dateTextView!!.text = dateToBeSet
//    }
//
//    override fun onCreateOptionsMenu(menu: Menu): Boolean {
//        val menuInflater = menuInflater
//        menuInflater.inflate(R.menu.add_expense_activity_menu, menu)
//        return super.onCreateOptionsMenu(menu)
//    }
//
//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        when (item.itemId) {
//            android.R.id.home -> finish()
//            R.id.saveButton ->                 // COMPLETED: 10-09-2018 1.Retrieve and Save data to database and also update the recycler view
//                if (amountTextInputEditText!!.text.toString().isEmpty()
//                    || descriptionTextInputEditText!!.text.toString().isEmpty()
//                ) {
//                    if (amountTextInputEditText!!.text.toString()
//                            .isEmpty()
//                    ) amountTextInputEditText!!.error =
//                        "Amount cannot be empty"
//                    if (descriptionTextInputEditText!!.text.toString()
//                            .isEmpty()
//                    ) descriptionTextInputEditText!!.error =
//                        "Please write some description"
//                } else {
//                    amount = amountTextInputEditText!!.text.toString().toInt()
//                    description = descriptionTextInputEditText!!.text.toString()
//                    dateOfExpense = myCalendar!!.time
//                    categoryOfExpense =
//                        if (intentFrom == SyncStateContract.Constants.addIncomeString || intentFrom == SyncStateContract.Constants.editIncomeString) "Income" else categories!![categorySpinner!!.selectedItemPosition]
//                    val mTransactionEntry = TransactionEntry(
//                        amount,
//                        categoryOfExpense,
//                        description,
//                        dateOfExpense,
//                        categoryOfTransaction
//                    )
//                    if (intentFrom == SyncStateContract.Constants.addIncomeString || intentFrom == SyncStateContract.Constants.addExpenseString) {
//                        AppExecutors.getInstance().diskIO().execute(Runnable {
//                            appDatabase.transactionDao().insertExpense(mTransactionEntry)
//                        })
//                        val inputManager =
//                            getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
//                        inputManager.hideSoftInputFromWindow(
//                            currentFocus!!.windowToken,
//                            InputMethodManager.HIDE_NOT_ALWAYS
//                        )
//                        Snackbar.make(currentFocus!!, "Transaction Added", Snackbar.LENGTH_LONG)
//                            .show()
//                    } else {
//                        mTransactionEntry.setId(transactionid)
//                        AppExecutors.getInstance().diskIO().execute(Runnable {
//                            appDatabase.transactionDao().updateExpenseDetails(mTransactionEntry)
//                        })
//                        val inputManager =
//                            getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
//                        inputManager.hideSoftInputFromWindow(
//                            currentFocus!!.windowToken,
//                            InputMethodManager.HIDE_NOT_ALWAYS
//                        )
//                        Snackbar.make(currentFocus!!, "Transaction Updated", Snackbar.LENGTH_LONG)
//                            .show()
//                    }
//                    Handler().postDelayed({ finish() }, 1000)
//                }
//        }
//        return true
//    }
//
//    companion object {
//        //private var appDatabase: AppDatabase? = null
//        private val LOG_TAG = AddExpenseActivity::class.java.simpleName
//    }
//}