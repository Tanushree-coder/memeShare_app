package com.example.xpenso

class ExpenseList(var category: String, var amount: Int)