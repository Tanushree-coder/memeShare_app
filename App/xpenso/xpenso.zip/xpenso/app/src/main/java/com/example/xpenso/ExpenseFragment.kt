package com.example.xpenso
//
//import android.arch.lifecycle.Observer
//import android.arch.lifecycle.ViewModelProviders
//import android.os.Bundle
//import android.support.design.widget.Snackbar
//import android.support.v4.app.Fragment
//import android.support.v7.widget.LinearLayoutManager
//import android.support.v7.widget.RecyclerView
//import android.support.v7.widget.helper.ItemTouchHelper
//import android.util.Log
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import com.example.xpenso.transactionDb.AppDatabase
//import com.example.xpenso.transactionDb.AppExecutors
//import com.example.xpenso.transactionDb.TransactionEntry
//import com.example.xpenso.transactionDb.TransactionViewModel
//
//class ExpenseFragment : Fragment() {
//    private var rv: RecyclerView? = null
//    private var transactionEntries: List<TransactionEntry>? = null
//    private var customAdapter: CustomAdapter? = null
//    var transactionViewModel: TransactionViewModel? = null
//    private var mAppDb: AppDatabase? = null
//    override fun onCreateView(
//        inflater: LayoutInflater,
//        container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View? {
//        val view = inflater.inflate(R.layout.fragment_expense, container, false)
//        rv = view.findViewById(R.id.transactionRecyclerView)
//        rv.setHasFixedSize(true)
//        transactionEntries = ArrayList<TransactionEntry>()
//        rv.setLayoutManager(LinearLayoutManager(activity))
//        mAppDb = AppDatabase.getInstance(context)
//        ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
//            override fun onMove(
//                recyclerView: RecyclerView,
//                viewHolder: RecyclerView.ViewHolder,
//                target: RecyclerView.ViewHolder
//            ): Boolean {
//                return false
//            }
//
//            // Called when a user swipes right on a ViewHolder
//            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, swipeDir: Int) {
//                // Here is where you'll implement swipe to delete
//                // COMPLETED (1) Get the diskIO Executor from the instance of AppExecutors and
//                // call the diskIO execute method with a new Runnable and implement its run method
//                AppExecutors.getInstance().diskIO().execute(Runnable {
//                    val position = viewHolder.adapterPosition
//                    val transactionEntries: List<TransactionEntry>? =
//                        customAdapter!!.getTransactionEntries()
//                    mAppDb.transactionDao().removeExpense(transactionEntries!![position])
//                })
//                Snackbar.make(view, "Transaction Deleted", Snackbar.LENGTH_LONG).show()
//            }
//        }).attachToRecyclerView(rv)
//        setupViewModel()
//        return view
//    }
//
//    fun setupViewModel() {
//        transactionViewModel = ViewModelProviders.of(this)
//            .get(TransactionViewModel::class.java)
//        transactionViewModel.getExpenseList()
//            .observe(this,
//                Observer<List<Any>?> { transactionEntriesFromDb ->
//                    Log.i(LOG_TAG, "Actively retrieving from DB")
//                    transactionEntries = transactionEntriesFromDb
//                    //                        Logging to check DB values
//                    for (i in transactionEntries!!.indices) {
//                        val description: String = transactionEntries!![i].getDescription()
//                        val amount: Int = transactionEntries!![i].getAmount()
//                        //Log.i("DESCRIPTION AMOUNT",description + String.valueOf(amount));
//                    }
//
//                    //                        Setting Adapter
//                    customAdapter = CustomAdapter(activity!!, transactionEntries)
//                    rv!!.adapter = customAdapter
//                })
//    }
//
//    companion object {
//        private val LOG_TAG = ExpenseFragment::class.java.simpleName
//    }
//}