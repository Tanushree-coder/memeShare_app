package com.example.xpenso
//
//import android.app.DownloadManager.Query
//import android.arch.lifecycle.LiveData
//import android.arch.persistence.room.Dao
//import android.arch.persistence.room.Delete
//import android.arch.persistence.room.Insert
//import android.arch.persistence.room.OnConflictStrategy
//import android.arch.persistence.room.Update
//
//
//@Dao
//interface TransactionDao {
//    @Query("select * from transactionTable order by date DESC")
//    fun loadAllTransactions(): LiveData<List<TransactionEntry?>?>?
//
//    @Query("select * from transactionTable where id = :id")
//    fun loadExpenseById(id: Int): LiveData<TransactionEntry?>?
//
//    @Query("select sum(amount) from transactionTable where transactionType =:transactionType")
//    fun getAmountByTransactionType(transactionType: String?): Int
//
//    @Query("select sum(amount) from transactionTable where transactionType =:transactionType and  date between :startDate and :endDate")
//    fun getAmountbyCustomDates(transactionType: String?, startDate: Long, endDate: Long): Int
//
//    @Query("select sum(amount) from transactionTable where category=:category")
//    fun getSumExpenseByCategory(category: String?): Int
//
//    @Query("select sum(amount) from transactionTable where category=:category and date between :startDate and :endDate")
//    fun getSumExpenseByCategoryCustomDate(category: String?, startDate: Long, endDate: Long): Int
//
//    @get:Query("select min(date) from transactionTable ")
//    val firstDate: Long
//
//    @Insert(onConflict = OnConflictStrategy.REPLACE)
//    fun insertExpense(transactionEntry: TransactionEntry?)
//
//    @Delete
//    fun removeExpense(transactionEntry: TransactionEntry?)
//
//    @Update(onConflict = OnConflictStrategy.REPLACE)
//    fun updateExpenseDetails(transactionEntry: TransactionEntry?)
//}