package com.example.xpenso
import kotlinx.android.synthetic.main.activity_main.*

import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.support.design.widget.TabLayout
import android.support.v4.view.ViewPager
import android.support.v7.app.AppCompatActivity
import android.view.View
import com.example.xpenso.SectionsPageAdapter
//import com.example.xpenso.CustomBottomSheetDialogFragment


class MainActivity : AppCompatActivity() {
    private var mViewPager: ViewPager? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mViewPager = findViewById(R.id.container)
        setupViewPager(mViewPager)
        val tabLayout = findViewById<TabLayout>(R.id.tabs)
        tabLayout.setupWithViewPager(mViewPager)
        //fab = findViewById<View>(R.id.fab) as FloatingActionButton
//        fab!!.setOnClickListener {
//            CustomBottomSheetDialogFragment().show(
//                supportFragmentManager,
//                "Dialog"
//            )
//        }
    }

    private fun setupViewPager(viewPager: ViewPager?) {
        val adapter = SectionsPageAdapter(supportFragmentManager)
        //adapter.addFragment(ExpenseFragment(), "Expenses")
        //adapter.addFragment(BalanceFragment(), "Balance")
        viewPager!!.adapter = adapter
    }

    companion object {
        var fab: FloatingActionButton? = null
    }
}