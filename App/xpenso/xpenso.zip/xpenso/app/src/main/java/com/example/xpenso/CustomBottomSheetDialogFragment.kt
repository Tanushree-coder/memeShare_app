package com.example.xpenso
//
//import android.content.Intent
//import android.os.Bundle
//import android.provider.SyncStateContract
//import android.support.design.widget.BottomSheetDialogFragment
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import android.widget.Button
//
//
//class CustomBottomSheetDialogFragment : BottomSheetDialogFragment() {
//    var addIncomeButton: Button? = null
//    var addExpenseButton: Button? = null
//    override fun onCreateView(
//        inflater: LayoutInflater,
//        container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View? {
//        val v = inflater.inflate(R.layout.bottom_sheet_fragment, container, false)
//        addIncomeButton = v.findViewById(R.id.bottom_sheet_income_btn)
//        addExpenseButton = v.findViewById(R.id.bottom_sheet_expense_btn)
//        addIncomeButton.setOnClickListener(View.OnClickListener {
//            dismiss()
//            val intent = Intent(activity, AddExpenseActivity::class.java)
//            intent.putExtra("from", SyncStateContract.Constants.addIncomeString)
//            startActivity(intent)
//        })
//        addExpenseButton.setOnClickListener(View.OnClickListener {
//            dismiss()
//            val intent = Intent(activity, AddExpenseActivity::class.java)
//            intent.putExtra("from", SyncStateContract.Constants.addExpenseString)
//            startActivity(intent)
//        })
//        return v
//    }
//}